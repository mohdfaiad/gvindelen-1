//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "Main.h"
#pragma package(smart_init)
#pragma link "IB_Services"
#pragma resource "*.dfm"
TFormMain *FormMain;
//---------------------------------------------------------------------------
__fastcall TFormMain::TFormMain(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::BExitClick(TObject *Sender)
{ Application->Terminate(); }
//---------------------------------------------------------------------------
void __fastcall TFormMain::BBackupClick(TObject *Sender)
{
OpenDialogBackup->Options.Clear();
OpenDialogBackup->Options << ofAllowMultiSelect;
OpenDialogDatabase->Options.Clear();
OpenDialogDatabase->Options << ofFileMustExist;
if (!OpenDialogDatabase->Execute()) return;
if (!OpenDialogBackup->Execute()) return;
BackupService1->DatabaseName = OpenDialogDatabase->FileName;
BackupService1->BackupFile->Clear();
Memo1->Clear();
Memo1->Lines->Add("*** Database file: ***");
Memo1->Lines->Add(BackupService1->DatabaseName);
Memo1->Lines->Add("*** Backup file(s): ***");
for (int i = 0; i < OpenDialogBackup->Files->Count; i ++)
{ BackupService1->BackupFile->Add(OpenDialogBackup->Files->Strings[i]);
  Memo1->Lines->Add(OpenDialogBackup->Files->Strings[i]);
}
Memo1->Lines->Add(
  "==================== Backup started ====================");
BackupService1->Active = true;
BExit->Enabled = false;
BBackup->Enabled = false;
BRestore->Enabled = false;
BackupService1->ServiceStart();
while (!BackupService1->Eof)
  Memo1->Lines->Add(BackupService1->GetNextLine());
BackupService1->Active = false;
BExit->Enabled = true;
BBackup->Enabled = true;
BRestore->Enabled = true;
Memo1->Lines->Add(
  "==================== Backup ended ====================");        
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::BRestoreClick(TObject *Sender)
{
OpenDialogBackup->Options.Clear();
OpenDialogBackup->Options << ofAllowMultiSelect << ofFileMustExist;
OpenDialogDatabase->Options.Clear();
OpenDialogDatabase->Options << ofAllowMultiSelect;
if (!OpenDialogDatabase->Execute()) return;
if (!OpenDialogBackup->Execute()) return;
RestoreService1->DatabaseName->Clear();
RestoreService1->BackupFile->Clear();
Memo1->Clear();
Memo1->Lines->Add("*** Database file(s): ***");
for (int i = 0; i < OpenDialogDatabase->Files->Count; i ++)
{ RestoreService1->DatabaseName->Add(OpenDialogDatabase->Files->Strings[i]);
  Memo1->Lines->Add(OpenDialogDatabase->Files->Strings[i]);
}
Memo1->Lines->Add("*** Backup file(s): ***");
for (int i = 0; i < OpenDialogBackup->Files->Count; i ++)
{ RestoreService1->BackupFile->Add(OpenDialogBackup->Files->Strings[i]);
  Memo1->Lines->Add(OpenDialogBackup->Files->Strings[i]);
}
Memo1->Lines->Add(
  "==================== Restore started ====================");
RestoreService1->Active = true;
BExit->Enabled = false;
BBackup->Enabled = false;
BRestore->Enabled = false;
RestoreService1->ServiceStart();
while (!RestoreService1->Eof)
  Memo1->Lines->Add(RestoreService1->GetNextLine());
RestoreService1->Active = false;
BExit->Enabled = true;
BBackup->Enabled = true;
BRestore->Enabled = true;
Memo1->Lines->Add(
  "==================== Restore ended ====================");        
}
//---------------------------------------------------------------------------
