//---------------------------------------------------------------------------

#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include "IB_Services.hpp"
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TFormMain : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TButton *BExit;
        TButton *BBackup;
        TButton *BRestore;
        TpFIBBackupService *BackupService1;
        TpFIBRestoreService *RestoreService1;
        TMemo *Memo1;
        TOpenDialog *OpenDialogBackup;
        TOpenDialog *OpenDialogDatabase;
        void __fastcall BExitClick(TObject *Sender);
        void __fastcall BBackupClick(TObject *Sender);
        void __fastcall BRestoreClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TFormMain(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormMain *FormMain;
//---------------------------------------------------------------------------
#endif
